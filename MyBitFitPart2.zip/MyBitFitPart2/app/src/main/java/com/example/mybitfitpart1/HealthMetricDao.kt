package com.example.mybitfitpart1

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HealthMetricDao {
    @Insert
    suspend fun insert(healthMetric: HealthMetric)

    @Delete
    suspend fun delete(healthMetric: HealthMetric)

    @Query("SELECT * FROM health_metric ORDER BY id DESC")
    fun getAll(): Flow<List<HealthMetric>>

    /**
     * This query will only work correctly for metric values that can be cast to a number.
     * It will ignore non-numeric values.
     */
    @Query("SELECT AVG(CAST(metric_value AS REAL)) FROM health_metric WHERE metric_name = :metricName AND metric_value GLOB '*[0-9]*'")
    fun getAverage(metricName: String): Flow<Double?>

    @Query("SELECT SUM(CAST(metric_value AS REAL)) FROM health_metric WHERE metric_name = 'Water Intake' AND metric_value GLOB '*[0-9]*'")
    fun getTotalWaterIntake(): Flow<Double?>
}
