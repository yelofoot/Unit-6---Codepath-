package com.example.mybitfitpart1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RatingBar
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class HealthMetricAdapter(private val onItemLongClickListener: (HealthMetric) -> Unit) : ListAdapter<HealthMetric, HealthMetricAdapter.HealthMetricViewHolder>(HealthMetricDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HealthMetricViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.metric_item, parent, false)
        return HealthMetricViewHolder(view)
    }

    override fun onBindViewHolder(holder: HealthMetricViewHolder, position: Int) {
        val metric = getItem(position)
        holder.bind(metric)
        holder.itemView.setOnLongClickListener {
            onItemLongClickListener(metric)
            true
        }
    }

    class HealthMetricViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val metricNameTextView: TextView = itemView.findViewById(R.id.metricNameTextView)
        private val metricValueTextView: TextView = itemView.findViewById(R.id.metricValueTextView)
        private val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        private val sleepRatingBar: RatingBar = itemView.findViewById(R.id.sleepRatingBarDisplay)

        fun bind(metric: HealthMetric) {
            metricNameTextView.text = metric.metricName
            dateTextView.text = metric.date

            val valueText = when (metric.metricName) {
                "Water Intake" -> "${metric.metricValue} fl oz"
                "Sleep" -> "${metric.metricValue} hours"
                else -> metric.metricValue
            }
            metricValueTextView.text = valueText

            if (metric.metricName == "Sleep" && metric.sleepRating != null) {
                sleepRatingBar.isVisible = true
                sleepRatingBar.rating = metric.sleepRating
            } else {
                sleepRatingBar.isVisible = false
            }
        }
    }
}

class HealthMetricDiffCallback : DiffUtil.ItemCallback<HealthMetric>() {
    override fun areItemsTheSame(oldItem: HealthMetric, newItem: HealthMetric): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: HealthMetric, newItem: HealthMetric): Boolean {
        return oldItem == newItem
    }
}