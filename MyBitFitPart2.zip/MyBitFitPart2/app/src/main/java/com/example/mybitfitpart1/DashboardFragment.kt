package com.example.mybitfitpart1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.text.DecimalFormat

class DashboardFragment : Fragment() {

    private lateinit var db: AppDatabase
    private lateinit var healthMetricDao: HealthMetricDao
    private val adapter = HealthMetricAdapter(::deleteMetric)
    private lateinit var summaryTextView: TextView
    private lateinit var waterIntakeTextView: TextView
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        summaryTextView = view.findViewById(R.id.summaryTextView)
        waterIntakeTextView = view.findViewById(R.id.waterIntakeTextView)
        recyclerView = view.findViewById(R.id.recyclerView)

        // Database setup
        db = AppDatabase.getInstance(requireContext().applicationContext)
        healthMetricDao = db.healthMetricDao()

        // RecyclerView setup
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Observe data
        lifecycleScope.launch {
            healthMetricDao.getAll().collect { metrics ->
                adapter.submitList(metrics)
            }
        }

        // Observe average sleep
        lifecycleScope.launch {
            healthMetricDao.getAverage("Sleep").collect { average ->
                val df = DecimalFormat("#.##")
                val formattedAverage = if (average != null) df.format(average) else "N/A"
                summaryTextView.text = "Average Sleep: $formattedAverage hours"
            }
        }

        // Observe total water intake
        lifecycleScope.launch {
            healthMetricDao.getTotalWaterIntake().collect { total ->
                val df = DecimalFormat("#.##")
                val formattedTotal = if (total != null) df.format(total) else "0"
                waterIntakeTextView.text = "Total Water Intake: $formattedTotal fl oz"
            }
        }
    }

    private fun deleteMetric(metric: HealthMetric) {
        lifecycleScope.launch {
            healthMetricDao.delete(metric)
        }
    }
}