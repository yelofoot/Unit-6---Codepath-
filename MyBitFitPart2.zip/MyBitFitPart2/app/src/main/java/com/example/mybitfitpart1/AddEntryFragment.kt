package com.example.mybitfitpart1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.Spinner
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddEntryFragment : Fragment() {

    private lateinit var db: AppDatabase
    private lateinit var healthMetricDao: HealthMetricDao

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_entry, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getInstance(requireContext().applicationContext)
        healthMetricDao = db.healthMetricDao()

        val metricNameSpinner: Spinner = view.findViewById(R.id.metricNameSpinner)
        val metricValueEditText: EditText = view.findViewById(R.id.metricValueEditText)
        val sleepRatingBar: RatingBar = view.findViewById(R.id.sleepRatingBar)
        val saveButton: Button = view.findViewById(R.id.saveButton)

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.metric_options,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            metricNameSpinner.adapter = adapter
        }

        metricNameSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedMetric = parent?.getItemAtPosition(position).toString()
                sleepRatingBar.isVisible = selectedMetric == "Sleep"
                metricValueEditText.hint = when (selectedMetric) {
                    "Water Intake" -> "in fl oz"
                    "Sleep" -> "in hours"
                    "Vitamins" -> "Count"
                    else -> "Value"
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }

        saveButton.setOnClickListener {
            val name = metricNameSpinner.selectedItem.toString()
            val value = metricValueEditText.text.toString()
            val currentDate = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
            val rating = if (sleepRatingBar.isVisible) sleepRatingBar.rating else null

            if (name.isNotEmpty() && value.isNotEmpty()) {
                lifecycleScope.launch {
                    healthMetricDao.insert(HealthMetric(
                        date = currentDate, 
                        metricName = name, 
                        metricValue = value,
                        sleepRating = rating
                    ))
                    // Navigate back to the dashboard
                    findNavController().popBackStack()
                }
            } else {
                Toast.makeText(requireContext(), "Please enter a valid value", Toast.LENGTH_SHORT).show()
            }
        }
    }
}