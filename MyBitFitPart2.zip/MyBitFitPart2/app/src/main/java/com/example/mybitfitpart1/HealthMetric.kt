package com.example.mybitfitpart1

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "health_metric")
data class HealthMetric(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "date") val date: String?,
    @ColumnInfo(name = "metric_name") val metricName: String?,
    @ColumnInfo(name = "metric_value") val metricValue: String?,
    @ColumnInfo(name = "sleep_rating") val sleepRating: Float? = null
)