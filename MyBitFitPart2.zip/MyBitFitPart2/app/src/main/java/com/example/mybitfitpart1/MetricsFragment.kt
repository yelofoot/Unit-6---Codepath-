package com.example.mybitfitpart1

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class MetricsFragment : Fragment() {

    private lateinit var db: AppDatabase
    private lateinit var healthMetricDao: HealthMetricDao
    private lateinit var sleepChart: BarChart
    private lateinit var waterChart: BarChart

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_metrics, container, false)
        sleepChart = view.findViewById(R.id.sleepChart)
        waterChart = view.findViewById(R.id.waterChart)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getInstance(requireContext().applicationContext)
        healthMetricDao = db.healthMetricDao()

        lifecycleScope.launch {
            healthMetricDao.getAll().collect { metrics ->
                val sleepMetrics = metrics.filter { it.metricName == "Sleep" }
                val waterMetrics = metrics.filter { it.metricName == "Water Intake" }

                if (sleepMetrics.isNotEmpty()) {
                    setupChart(sleepChart, sleepMetrics, "Sleep Hours", Color.BLUE)
                }
                if (waterMetrics.isNotEmpty()) {
                    setupChart(waterChart, waterMetrics, "Water (fl oz)", Color.CYAN)
                }
            }
        }
    }

    private fun setupChart(chart: BarChart, metrics: List<HealthMetric>, label: String, color: Int) {
        val entries = metrics.mapIndexed { index, metric ->
            BarEntry(index.toFloat(), metric.metricValue?.toFloatOrNull() ?: 0f)
        }

        val dataSet = BarDataSet(entries, label)
        dataSet.color = color

        val barData = BarData(dataSet)
        chart.data = barData

        // Customize X-axis
        val xAxis = chart.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(metrics.map { it.date })
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)

        chart.description.isEnabled = false
        chart.invalidate() // Refresh the chart
    }
}